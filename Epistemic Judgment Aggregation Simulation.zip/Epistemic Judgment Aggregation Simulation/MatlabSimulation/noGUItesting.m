
%   Test class. Executes a simulation witout GUI
%			
%   Code from the Bachelor Thesis: "Quantitative Epistemologische Demokratie:
%   Simulation und numerischer Vergleich der konklusions- und der prämissenbasierten
%   Judgment Aggregation", Lukas Bosch



setPath;
name = "Test";
premises = 2;
voters = 21;
resultRelation = "A&B";
corr = 0;
runs = 10000;
%Prämissen-Wkeiten
priorProb = [0.5, 0.5];
pIterations = [0.01,0.02:0.02:0.98,0.99];

x = Simulation(premises, voters, resultRelation, corr, runs, pIterations, name);
%S = Simulation.genScens(premises,resultRelation);
tic
x.simulate;
toc

%x.Result


