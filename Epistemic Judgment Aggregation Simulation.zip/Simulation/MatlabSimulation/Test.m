% some example data
corr = 0.7;
mu = [0.5, 0.5];
Var = mu.*(1-mu);
cova = corr * Var(1);
Cov = diag(Var);
for i = 1:2
    for j = 1:2
        if i ~= j
            Cov(i,j) = cova;
        end
    end
end
%sigma = [1 0.2; 0.6 1];

rng('default')  % For reproducibility
R = mvnrnd(mu,Cov,100000);
U1 = R(:,1);
U2 = R(:,2);

% x = randn(1000,1);
% y = randn(1000,1);

h = scatterhist(U1,U2,'Location','NorthEast',...
                'Direction','out',...
                'Color','k',...
                'Marker',".",...
                'MarkerSize',4);
pbaspect([1 1 1])

legend('data')
legend boxoff
grid on
     
