% This functions sets the correct path for the software package coming with
% the Bachelor Thesis "Quantitative Epistemologische Demokratie:
% Simulation und Vergleich der konklusions- und der Prämissenbasierten
% Judgment Aggregation"
%			
% Code from the Bachelor Thesis: 'Quantitative Epistemologische Demokratie:
% Simulation und Vergleich der konklusions- und der Prämissenbasierten
% Judgment Aggregation", Lukas Bosch, KIT

p = pwd;
addpath(genpath(p));
% addpath(fullfile(p,'lib'));
% addpath(fullfile(p,'save'));
